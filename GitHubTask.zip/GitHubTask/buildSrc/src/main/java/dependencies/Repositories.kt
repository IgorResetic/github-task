package dependencies

object Repositories {
    const val FABRIC = "https://maven.fabric.io/public"
}
