package dependencies

object Java {
    const val JAVA_VERSION = "1.8"
}
