package dependencies

object Application {
    const val APP_ID = "ccom.example.githubtask"
    const val VERSION_CODE = 1
    const val VERSION_NAME = "1.0"
}
