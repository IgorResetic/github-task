package com.example.githubtask.persistence

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.githubtask.models.database.GItHubRepoEntity
import com.example.githubtask.models.database.UserEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi

@ExperimentalCoroutinesApi
@Database(
    entities = [
        UserEntity::class,
        GItHubRepoEntity::class],
    version = 2,
    exportSchema = false
)
abstract class GithubDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao

    abstract fun repoDao(): RepoDao

    companion object {
        val DATABASE_NAME: String = "blog_db"
    }
}
