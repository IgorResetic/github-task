package com.example.githubtask.network.mappers

import com.example.githubtask.models.api.GitHubRepoNetworkEntity
import com.example.githubtask.models.domain.GitHubRepo
import com.example.githubtask.util.EntityMapper
import javax.inject.Inject

class GitHUbRepoNetworkMapper
@Inject
constructor(): EntityMapper<GitHubRepoNetworkEntity, GitHubRepo> {
    override fun mapFromEntity(entity: GitHubRepoNetworkEntity): GitHubRepo {
        return GitHubRepo(
            name = entity.name,
            fullName = entity.fullName,
            owner = entity.owner,
            htmlUrl = entity.htmlUrl,
            description = entity.description,
            stargazersCount = entity.stargazersCount,
            watchersCount = entity.watchersCount,
            forksCount = entity.forksCount,
            language = entity.language
        )
    }

    override fun mapToEntity(domainModel: GitHubRepo): GitHubRepoNetworkEntity {
        return GitHubRepoNetworkEntity(
            name = domainModel.name,
            fullName = domainModel.fullName,
            owner = domainModel.owner,
            htmlUrl = domainModel.htmlUrl,
            description = domainModel.description,
            stargazersCount = domainModel.stargazersCount,
            watchersCount = domainModel.watchersCount,
            forksCount = domainModel.forksCount,
            language = domainModel.language
        )
    }
}
