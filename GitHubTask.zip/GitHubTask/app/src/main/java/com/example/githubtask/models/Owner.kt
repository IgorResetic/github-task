package com.example.githubtask.models

data class Owner(
    val login: String,
    val avatarUrl: String?
)
