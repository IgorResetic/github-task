package com.example.githubtask.ui.search

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.githubtask.R
import com.example.githubtask.models.domain.User
import com.example.githubtask.util.DataState
import kotlinx.android.synthetic.main.fragment_search.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import javax.inject.Inject
import androidx.lifecycle.Observer
import dagger.hilt.android.AndroidEntryPoint

@ExperimentalCoroutinesApi
@AndroidEntryPoint
class SearchFragment
@Inject
constructor() : Fragment() {

    private val viewModel: SearchViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        toRepo.setOnClickListener { navRepo() }

        toUser.setOnClickListener { navUser() }
        subscribeObservers()
        viewModel.setStateEvent(MainStateEvent.GetBlogsEvent)
    }

    private fun subscribeObservers() {
        viewModel.dataState.observe(viewLifecycleOwner, Observer { dataState ->
            when (dataState) {
                is DataState.Success<User> -> {
                    Log.d("TestRepository", dataState.data.login)
                }
                is DataState.Error -> {
                    Log.d("TestRepository", "Error")
                }
                is DataState.Loading -> {
                    Log.d("TestRepository", "Loading")
                }
            }
        })
    }

    private fun navRepo() {
        findNavController().navigate(R.id.action_searchFragment_to_repositoryDetailFragment)
    }
    private fun navUser() {
        findNavController().navigate(R.id.action_searchFragment_to_userDetailFragment)
    }
}
