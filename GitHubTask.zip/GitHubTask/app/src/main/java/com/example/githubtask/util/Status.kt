package com.example.githubtask.util

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
