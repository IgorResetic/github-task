package com.example.githubtask.ui.userdetail

import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import com.example.githubtask.R
import com.example.githubtask.models.domain.User
import com.example.githubtask.ui.search.MainStateEvent
import com.example.githubtask.ui.search.SearchViewModel
import com.example.githubtask.util.DataState
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.fragment_user_detail.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import retrofit2.http.Url
import javax.inject.Inject

@ExperimentalCoroutinesApi
@AndroidEntryPoint
class UserDetailFragment
@Inject
constructor() : Fragment() {

    private val viewModel: UserDetailViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_user_detail, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        subscribeObservers()
        viewModel.setStateEvent(UserStateEvent.GetUserEvent)
    }

    private fun subscribeObservers() {
        viewModel.dataState.observe(viewLifecycleOwner, Observer { dataState ->
            when (dataState) {
                is DataState.Success<User> -> {
                    Log.d("TestRepository", dataState.data.avatarUrl)
                    //iw_user_image.setImageURI(dataState.data.avatarUrl as Uri?)
                }
                is DataState.Error -> {
                    Log.d("TestRepository", "Error")
                }
                is DataState.Loading -> {
                    Log.d("TestRepository", "Loading")
                }
            }
        })
    }
}
