package com.example.githubtask.repository

interface Repository
