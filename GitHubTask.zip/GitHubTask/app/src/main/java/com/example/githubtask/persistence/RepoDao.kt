package com.example.githubtask.persistence

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.githubtask.models.database.GItHubRepoEntity

@Dao
interface RepoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(vararg repos: GItHubRepoEntity)

    @Query("SELECT * FROM github_repos WHERE owner_login = :ownerLogin AND name = :name")
    suspend fun load(ownerLogin: String, name: String): GItHubRepoEntity
}
