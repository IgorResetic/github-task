package com.example.githubtask.models.api

data class RepoSearchResponseEntity(
    val total: Int = 0,
    val items: List<GitHubRepoNetworkEntity>
) {
    var nextPage: Int? = null
}
