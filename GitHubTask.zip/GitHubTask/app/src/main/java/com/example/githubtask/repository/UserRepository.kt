package com.example.githubtask.repository

import android.os.UserManager
import android.util.Log
import com.example.githubtask.models.domain.User
import com.example.githubtask.network.GithubApiService
import com.example.githubtask.network.mappers.UserNetworkMapper
import com.example.githubtask.persistence.UserDao
import com.example.githubtask.persistence.mappers.UserMapper
import com.example.githubtask.util.DataState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.lang.Exception
import javax.inject.Inject

class UserRepository
constructor(
    private val userDao: UserDao,
    private val githubApiService: GithubApiService,
    private val userMapper: UserMapper,
    private val userNetworkMapper: UserNetworkMapper
) : Repository {
    suspend fun getUser(): Flow<DataState<User>> = flow {
        emit(DataState.Loading)
        try {
            val networkUser = githubApiService.getUser("flutter")
            val user = userNetworkMapper.mapFromEntity(networkUser)
            userDao.insert(userMapper.mapToEntity(user))

            val cachedUser = userDao.findByLogin("flutter")
            emit(DataState.Success(userMapper.mapFromEntity(cachedUser)))
        } catch (e: Exception) {
            Log.d("TestRepository", "" + e.message)
            emit(DataState.Error(e))
        }
    }
}
