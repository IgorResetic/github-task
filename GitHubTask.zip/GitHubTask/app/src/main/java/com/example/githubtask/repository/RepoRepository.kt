package com.example.githubtask.repository

import com.example.githubtask.models.domain.GitHubRepo
import com.example.githubtask.network.GithubApiService
import com.example.githubtask.network.mappers.GitHUbRepoNetworkMapper
import com.example.githubtask.persistence.RepoDao
import com.example.githubtask.persistence.mappers.GitHubRepoMapper
import com.example.githubtask.util.DataState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class RepoRepository
constructor(
    private val repoDao: RepoDao,
    private val githubApiService: GithubApiService,
    private val gitHubRepoMapper: GitHubRepoMapper,
    private val gitHUbRepoNetworkMapper: GitHUbRepoNetworkMapper
) : Repository {
    suspend fun getGitHubRepo(): Flow<DataState<GitHubRepo>> = flow {
        emit(DataState.Loading)
        try {
            val networkRepo = githubApiService.getRepo("flutter", "buildroot")
            val repo = gitHUbRepoNetworkMapper.mapFromEntity(networkRepo)
            repoDao.insert(gitHubRepoMapper.mapToEntity(repo))

            val cachedRepo = repoDao.load("flutter", "buildroot")
            emit(DataState.Success(gitHubRepoMapper.mapFromEntity(cachedRepo)))
        } catch (e: Exception) {
            emit(DataState.Error(e))
        }
    }
}
